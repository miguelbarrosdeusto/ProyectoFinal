/*
 * hal_entry.h
 *
 *  Created on: 10 dic 2023
 *      Author: Hezitzaile
 */

#ifndef HAL_ENTRY_H_
#define HAL_ENTRY_H_

void pin_activate(uint32_t delay, bsp_io_port_pin_t pin);
void init_led(void);
void init_buzzer(void);
void init_pulsador(void);
void Delay(uint32_t ms);
void buzzer(void);
void ParpadearLED(int tiempoEncendido, int tiempoApagado);
void DisplayLCD(uint16_t value);
int nivel_velocidad(uint16_t valor);
uint16_t mediaMovil();
void pulsadorBoton(external_irq_callback_args_t *p_args);
void actualizarFiltro(uint16_t nuevaLectura);
void SystemOn();
void Peligro();
void timer_callback(timer_callback_args_t *p_args);

fsp_err_t icu_init(void);
fsp_err_t icu_enable(void);
void icu_deinit(void);

#endif /* HAL_ENTRY_H_ */
